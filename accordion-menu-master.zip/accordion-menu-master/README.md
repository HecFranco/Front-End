# accordion-menu
A simple solution for an accordion menu using vanilla javascript and some CSS3 properties.

Live demo [here](http://codepen.io/jamespr/pen/yyxXNP).
